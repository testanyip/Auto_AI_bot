import requests
import pytz
from datetime import datetime

bot_token = "8510592616:AAEkl42SSn-wuhB4ZysT4KW_xte3ZV4Fc9o"
chat_id = "5179697074"

hk_tz = pytz.timezone('Asia/Hong_Kong')
hk_time = datetime.now(hk_tz)
utc_time = datetime.utcnow()

message = f"""🤖 Bot 自動執行！
⏰ 香港時間：{hk_time.strftime('%Y-%m-%d %H:%M:%S HK')}
🌍 UTC時間：{utc_time.strftime('%Y-%m-%d %H:%M:%S UTC')}
🔄 每5分鐘一次！"""

url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
data = {"chat_id": chat_id, "text": message}

response = requests.post(url, data=data)
print(f"Status: {response.json()}")

if response.json().get("ok"):
    print("✅ Telegram 訊息已送出！")
else:
    print("❌ 發送失敗！")
